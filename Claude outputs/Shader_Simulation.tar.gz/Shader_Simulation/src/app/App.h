#pragma once

#include "app/Theme.h"
#include "rhi/RHI.h"
#include "shader/Annotations.h"
#include "textures/TextureLibrary.h"

#include <TextEditor.h>

#include <array>
#include <filesystem>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

struct GLFWwindow;

namespace app {

class App {
public:
    App(GLFWwindow* window, Fonts fonts);
    ~App();

    // Per frame, after ImGui::NewFrame(): advance time, hot-reload, compile, render the shader.
    void update();
    // Per frame, after update(): build the UI.
    void drawUI();

    void onFilesDropped(int count, const char** paths);
    bool quitRequested() const { return quit_; }

private:
    enum class Level { Info, Ok, Warn, Error };
    struct LogEntry {
        std::string time;
        Level level;
        std::string text;
    };
    struct UniformState {
        std::array<float, 4> f{};
        int i = 0;
    };

    // shader
    void compile(const char* reason);
    void applyDiagnostics(const std::vector<rhi::Diagnostic>& diags);
    void syncUniformDefaults();
    void renderShader();
    void collectBindings(std::vector<rhi::UniformValue>& values, std::vector<rhi::TextureBinding>& textures);

    // files
    void newShader();
    bool openShader(const std::filesystem::path& path);
    bool saveShader(const std::filesystem::path& path);
    void pollShaderFile();
    bool isDirty() const;
    void updateTitle();

    // ui
    void drawMenuBar();
    void drawDockspace();
    void drawEditor();
    void drawPreview();
    void drawConsole();
    void drawTextures();
    void drawUniforms();
    void drawOverlay();
    void drawPopups();
    void handleShortcuts();
    void setOverlay(bool on);

    void log(Level level, std::string text);

    GLFWwindow* window_;
    Fonts fonts_;
    std::unique_ptr<rhi::Device> device_;
    std::unique_ptr<textures::TextureLibrary> textures_;
    std::unique_ptr<rhi::RenderTarget> target_;
    std::unique_ptr<rhi::Program> program_;

    TextEditor editor_;
    TextEditor::Palette editorPalette_;
    size_t savedUndoIndex_ = 0;
    std::filesystem::path shaderPath_;
    std::filesystem::file_time_type shaderMtime_{};
    bool externalChangeWarned_ = false;

    shader::AnnotationMap annotations_;
    std::unordered_map<std::string, UniformState> uniformValues_;
    std::vector<rhi::Diagnostic> diagnostics_;
    std::vector<LogEntry> log_;
    bool scrollLog_ = false;

    // playback
    bool playing_ = true;
    double time_ = 0.0;
    double timeDelta_ = 0.0;
    int frame_ = 0;
    double lastClock_ = 0.0;
    double pollTimer_ = 0.0;

    // compile
    bool autoCompile_ = true;
    bool compileRequested_ = true;
    double lastCompileMs_ = 0.0;
    std::string lastCompiledSource_;

    // preview / output
    int outputMode_ = 0;  // 0 = fit panel, else fixed sizes
    int desiredW_ = 1280, desiredH_ = 720;
    std::array<float, 4> mouse_{};

    // view
    bool overlay_ = false;
    float overlayDim_ = 0.35f;
    bool layoutBuilt_ = false;
    bool resetLayout_ = false;
    bool quit_ = false;

    // popups
    enum class PathPopup { None, Open, SaveAs, AddImage };
    PathPopup pendingPopup_ = PathPopup::None;
    PathPopup activePopup_ = PathPopup::None;
    char pathBuf_[1024] = {};
};

}  // namespace app
