#include "app/App.h"

#include <GLFW/glfw3.h>
#include <imgui.h>
#include <imgui_internal.h>

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <fstream>
#include <regex>
#include <sstream>

namespace fs = std::filesystem;

namespace app {

extern const char* const kDefaultShader;

namespace {

constexpr const char* kWinEditor = "Editor";
constexpr const char* kWinPreview = "Preview";
constexpr const char* kWinConsole = "Console";
constexpr const char* kWinTextures = "Textures";
constexpr const char* kWinUniforms = "Uniforms";

struct OutputSize {
    const char* label;
    int w, h;
};
constexpr OutputSize kOutputs[] = {
    {"Fit panel", 0, 0},     {"1280 x 720", 1280, 720},   {"1920 x 1080", 1920, 1080},
    {"1080 x 1920", 1080, 1920}, {"2048 x 2048", 2048, 2048}, {"3840 x 2160", 3840, 2160},
};

const char* kFilterNames[] = {"Nearest", "Linear", "Trilinear"};
const char* kWrapNames[] = {"Repeat", "Clamp", "Mirror"};

std::string nowString() {
    const std::time_t t = std::time(nullptr);
    std::tm tm{};
#if defined(_WIN32)
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    char buf[16];
    std::strftime(buf, sizeof(buf), "%H:%M:%S", &tm);
    return buf;
}

std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return std::tolower(c); });
    return s;
}

bool isShaderFile(const fs::path& p) {
    const auto e = lower(p.extension().string());
    return e == ".frag" || e == ".fs" || e == ".glsl" || e == ".txt" || e == ".metal";
}

bool readFile(const fs::path& p, std::string& out) {
    std::ifstream in(p, std::ios::binary);
    if (!in) return false;
    std::ostringstream ss;
    ss << in.rdbuf();
    out = ss.str();
    return true;
}

// Returns the slot index encoded in a sampler name (u_tex3 / iChannel3), or -1.
int samplerSlotFromName(const std::string& name) {
    static const std::regex re(R"(^(?:u_tex|iChannel)(\d+)$)");
    std::smatch m;
    if (std::regex_match(name, m, re)) return std::stoi(m[1].str());
    return -1;
}

enum class Builtin { None, Time, TimeDelta, Frame, Resolution, Mouse };

Builtin builtinFor(const std::string& n) {
    if (n == "u_time" || n == "iTime") return Builtin::Time;
    if (n == "u_timeDelta" || n == "iTimeDelta") return Builtin::TimeDelta;
    if (n == "u_frame" || n == "iFrame") return Builtin::Frame;
    if (n == "u_resolution" || n == "iResolution") return Builtin::Resolution;
    if (n == "u_mouse" || n == "iMouse") return Builtin::Mouse;
    return Builtin::None;
}

ImTextureID texId(const rhi::Texture& t) { return static_cast<ImTextureID>(t.nativeHandle()); }

void accentButtonColors() {
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.776f, 0.957f, 0.196f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.886f, 1.0f, 0.478f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.70f, 0.88f, 0.15f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.055f, 0.059f, 0.071f, 1.0f));
}

}  // namespace

// ====================================================================== lifecycle

App::App(GLFWwindow* window, Fonts fonts) : window_(window), fonts_(fonts) {
    device_ = rhi::createGLDevice();
    textures_ = std::make_unique<textures::TextureLibrary>(*device_);
    target_ = device_->createRenderTarget(16, 16, rhi::Format::RGBA8);

    editor_.SetLanguage(TextEditor::Language::Glsl());
    editor_.SetTabSize(4);
    editor_.SetInsertSpacesOnTabs(true);
    editor_.SetShowMatchingBrackets(true);
    editor_.SetCompletePairedGlyphs(true);
    editor_.SetShowWhitespacesEnabled(false);
    editor_.SetChangeCallback([this] {
        if (autoCompile_) compileRequested_ = true;
    }, 300);
    editorPalette_ = editor_.GetPalette();

    lastClock_ = glfwGetTime();
    log(Level::Info, device_->name() + " · max " + std::to_string(device_->maxTextureUnits()) + " texture units");
    newShader();
}

App::~App() = default;

void App::log(Level level, std::string text) {
    log_.push_back({nowString(), level, std::move(text)});
    if (log_.size() > 1000) log_.erase(log_.begin(), log_.begin() + 200);
    scrollLog_ = true;
}

// ====================================================================== per-frame

void App::update() {
    const double now = glfwGetTime();
    timeDelta_ = now - lastClock_;
    lastClock_ = now;
    if (playing_) {
        time_ += timeDelta_;
        ++frame_;
    }

    pollTimer_ += timeDelta_;
    if (pollTimer_ > 0.5) {
        pollTimer_ = 0.0;
        pollShaderFile();
        for (const auto& name : textures_->pollHotReload()) log(Level::Info, "Reloaded texture " + name);
    }

    if (compileRequested_) {
        compileRequested_ = false;
        // The editor's change callback also fires after SetText(); skip no-op recompiles.
        if (editor_.GetText() != lastCompiledSource_) compile("edit");
    }

    handleShortcuts();
    renderShader();
}

void App::renderShader() {
    if (!program_) return;
    int w = desiredW_, h = desiredH_;
    if (outputMode_ > 0 && !overlay_) {
        w = kOutputs[outputMode_].w;
        h = kOutputs[outputMode_].h;
    }
    w = std::clamp(w, 1, 8192);
    h = std::clamp(h, 1, 8192);
    target_->resize(w, h);

    std::vector<rhi::UniformValue> values;
    std::vector<rhi::TextureBinding> bindings;
    collectBindings(values, bindings);
    device_->draw(*program_, *target_, values, bindings);
}

void App::collectBindings(std::vector<rhi::UniformValue>& values, std::vector<rhi::TextureBinding>& bindings) {
    auto& slots = textures_->slots();
    int nextUnit = 0;
    int autoSlot = 0;
    const int maxUnits = device_->maxTextureUnits();

    for (const auto& u : program_->uniforms()) {
        if (u.type == rhi::UniformType::Sampler2D) {
            if (nextUnit >= maxUnits) continue;
            int slot = samplerSlotFromName(u.name);
            if (slot < 0) slot = autoSlot++;
            const rhi::Texture* tex = &textures_->fallback();
            if (slot >= 0 && static_cast<size_t>(slot) < slots.size() && slots[static_cast<size_t>(slot)].texture)
                tex = slots[static_cast<size_t>(slot)].texture.get();
            bindings.push_back({u.location, nextUnit++, tex});
            continue;
        }

        rhi::UniformValue v;
        v.location = u.location;
        v.type = u.type;
        const float rw = static_cast<float>(target_->width());
        const float rh = static_cast<float>(target_->height());

        switch (builtinFor(u.name)) {
            case Builtin::Time: v.f[0] = static_cast<float>(time_); break;
            case Builtin::TimeDelta: v.f[0] = static_cast<float>(timeDelta_); break;
            case Builtin::Frame: v.i = frame_; v.f[0] = static_cast<float>(frame_); break;
            case Builtin::Resolution: v.f[0] = rw; v.f[1] = rh; v.f[2] = 1.0f; break;
            case Builtin::Mouse: std::copy(mouse_.begin(), mouse_.end(), v.f); break;
            case Builtin::None: {
                auto it = uniformValues_.find(u.name);
                if (it == uniformValues_.end()) break;
                std::copy(it->second.f.begin(), it->second.f.end(), v.f);
                v.i = it->second.i;
                break;
            }
        }
        if (v.type == rhi::UniformType::Float && builtinFor(u.name) == Builtin::Frame) v.f[0] = static_cast<float>(frame_);
        values.push_back(v);
    }
}

// ====================================================================== compile

void App::compile(const char* reason) {
    const std::string src = editor_.GetText();
    lastCompiledSource_ = src;
    auto result = device_->compileFragment(src);
    lastCompileMs_ = result.milliseconds;
    applyDiagnostics(result.diagnostics);

    const std::string file = shaderPath_.empty() ? "untitled.frag" : shaderPath_.filename().string();
    char ms[32];
    std::snprintf(ms, sizeof(ms), "%.1f ms", result.milliseconds);

    if (result.ok()) {
        program_ = std::move(result.program);
        annotations_ = shader::parseAnnotations(src);
        syncUniformDefaults();
        int user = 0, samplers = 0;
        for (const auto& u : program_->uniforms()) {
            if (u.type == rhi::UniformType::Sampler2D) ++samplers;
            else if (builtinFor(u.name) == Builtin::None) ++user;
        }
        log(Level::Ok, file + " compiled · " + device_->languageVersion() + " · " + ms + " (" + reason + ")");
        log(Level::Info, std::to_string(samplers) + " sampler(s), " + std::to_string(user) + " user uniform(s)");
        for (const auto& d : result.diagnostics)
            if (!d.isError) log(Level::Warn, "line " + std::to_string(d.line) + ": " + d.message);
    } else {
        int errors = 0;
        for (const auto& d : result.diagnostics) {
            if (d.isError) ++errors;
            log(d.isError ? Level::Error : Level::Warn,
                (d.line > 0 ? "line " + std::to_string(d.line) + ": " : std::string()) + d.message);
        }
        log(Level::Error, file + " failed (" + std::to_string(errors) + " error(s)) · keeping last good shader");
    }
}

void App::applyDiagnostics(const std::vector<rhi::Diagnostic>& diags) {
    diagnostics_ = diags;
    editor_.ClearMarkers();
    for (const auto& d : diags) {
        if (d.line <= 0) continue;
        const ImU32 numberColor = d.isError ? colors::Error : IM_COL32(255, 200, 90, 255);
        const ImU32 lineColor = d.isError ? IM_COL32(255, 80, 80, 45) : IM_COL32(255, 200, 90, 35);
        editor_.AddMarker(static_cast<size_t>(d.line - 1), numberColor, lineColor, d.message, d.message);
    }
}

void App::syncUniformDefaults() {
    for (const auto& u : program_->uniforms()) {
        if (u.type == rhi::UniformType::Sampler2D || builtinFor(u.name) != Builtin::None) continue;
        if (uniformValues_.count(u.name)) continue;
        UniformState s;
        auto a = annotations_.find(u.name);
        if (a != annotations_.end() && a->second.defaultValue) {
            s.f = *a->second.defaultValue;
        } else if (a != annotations_.end() && a->second.kind == shader::Annotation::Kind::Color) {
            s.f = {1, 1, 1, 1};
        } else if (a != annotations_.end() && a->second.kind == shader::Annotation::Kind::Slider) {
            s.f.fill(a->second.min);
        }
        s.i = static_cast<int>(s.f[0]);
        uniformValues_[u.name] = s;
    }
}

// ====================================================================== files

void App::newShader() {
    editor_.SetText(std::string(kDefaultShader));
    shaderPath_.clear();
    savedUndoIndex_ = editor_.GetUndoIndex();
    uniformValues_.clear();
    compileRequested_ = true;
    updateTitle();
}

bool App::openShader(const fs::path& path) {
    if (lower(path.extension().string()) == ".metal") {
        log(Level::Warn, "Metal shaders need the Metal backend (Milestone 3): " + path.string());
        return false;
    }
    std::string text;
    if (!readFile(path, text)) {
        log(Level::Error, "Could not open " + path.string());
        return false;
    }
    editor_.SetText(text);
    shaderPath_ = path;
    std::error_code ec;
    shaderMtime_ = fs::last_write_time(path, ec);
    savedUndoIndex_ = editor_.GetUndoIndex();
    externalChangeWarned_ = false;
    uniformValues_.clear();
    log(Level::Info, "Opened " + path.string());
    compile("open");
    updateTitle();
    return true;
}

bool App::saveShader(const fs::path& path) {
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) {
        log(Level::Error, "Could not write " + path.string());
        return false;
    }
    out << editor_.GetText();
    out.close();
    shaderPath_ = path;
    std::error_code ec;
    shaderMtime_ = fs::last_write_time(path, ec);
    savedUndoIndex_ = editor_.GetUndoIndex();
    externalChangeWarned_ = false;
    log(Level::Ok, "Saved " + path.string());
    updateTitle();
    return true;
}

void App::pollShaderFile() {
    if (shaderPath_.empty()) return;
    std::error_code ec;
    const auto t = fs::last_write_time(shaderPath_, ec);
    if (ec || t == shaderMtime_) return;
    if (isDirty()) {
        if (!externalChangeWarned_) {
            log(Level::Warn, shaderPath_.filename().string() + " changed on disk; you have unsaved edits, not reloading");
            externalChangeWarned_ = true;
        }
        return;
    }
    std::string text;
    if (!readFile(shaderPath_, text)) return;
    editor_.SetText(text);
    shaderMtime_ = t;
    savedUndoIndex_ = editor_.GetUndoIndex();
    compile("file changed on disk");
}

bool App::isDirty() const { return editor_.GetUndoIndex() != savedUndoIndex_; }

void App::updateTitle() {
    const std::string name = shaderPath_.empty() ? "untitled.frag" : shaderPath_.filename().string();
    glfwSetWindowTitle(window_, ("Shader Studio — " + name).c_str());
}

void App::onFilesDropped(int count, const char** paths) {
    for (int i = 0; i < count; ++i) {
        const fs::path p = paths[i];
        if (textures::TextureLibrary::isImageFile(p)) {
            if (auto err = textures_->addImage(p); !err.empty()) log(Level::Error, err);
            else
                log(Level::Ok, "Added texture " + p.filename().string() + " → u_tex" +
                                   std::to_string(textures_->slots().size() - 1));
        } else if (isShaderFile(p)) {
            openShader(p);
        } else {
            log(Level::Warn, "Unsupported file: " + p.string());
        }
    }
}

// ====================================================================== UI

void App::handleShortcuts() {
    if (ImGui::IsKeyPressed(ImGuiKey_F5, false)) compile("F5");
    if (ImGui::IsKeyPressed(ImGuiKey_F2, false)) setOverlay(!overlay_);
    if (overlay_ && ImGui::IsKeyPressed(ImGuiKey_Escape, false)) setOverlay(false);
    if (ImGui::Shortcut(ImGuiMod_Ctrl | ImGuiKey_S, ImGuiInputFlags_RouteGlobal)) {
        if (shaderPath_.empty()) pendingPopup_ = PathPopup::SaveAs;
        else saveShader(shaderPath_);
    }
    if (ImGui::Shortcut(ImGuiMod_Ctrl | ImGuiKey_O, ImGuiInputFlags_RouteGlobal)) pendingPopup_ = PathPopup::Open;
}

void App::setOverlay(bool on) {
    overlay_ = on;
    if (on) {
        auto p = editorPalette_;
        p[static_cast<size_t>(TextEditor::Color::background)] = IM_COL32(0, 0, 0, 0);
        p[static_cast<size_t>(TextEditor::Color::currentLineHighlight)] = IM_COL32(0, 0, 0, 80);
        editor_.SetPalette(p);
    } else {
        editor_.SetPalette(editorPalette_);
    }
}

void App::drawUI() {
    if (overlay_) {
        drawOverlay();
        drawPopups();
        return;
    }
    drawMenuBar();
    drawDockspace();
    drawEditor();
    drawPreview();
    drawConsole();
    drawTextures();
    drawUniforms();
    drawPopups();
}

void App::drawMenuBar() {
    if (!ImGui::BeginMainMenuBar()) return;

    ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(colors::Accent), "Shader Studio");
    ImGui::Separator();

    if (ImGui::BeginMenu("File")) {
        if (ImGui::MenuItem("New")) newShader();
        if (ImGui::MenuItem("Open…", "Ctrl/Cmd+O")) pendingPopup_ = PathPopup::Open;
        if (ImGui::MenuItem("Save", "Ctrl/Cmd+S")) {
            if (shaderPath_.empty()) pendingPopup_ = PathPopup::SaveAs;
            else saveShader(shaderPath_);
        }
        if (ImGui::MenuItem("Save As…")) pendingPopup_ = PathPopup::SaveAs;
        ImGui::Separator();
        if (ImGui::MenuItem("Quit")) quit_ = true;
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Shader")) {
        if (ImGui::MenuItem("Compile", "F5")) compile("menu");
        ImGui::MenuItem("Auto-compile while typing", nullptr, &autoCompile_);
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("View")) {
        if (ImGui::MenuItem("Overlay mode", "F2", overlay_)) setOverlay(!overlay_);
        if (ImGui::MenuItem("Reset layout")) resetLayout_ = true;
        ImGui::EndMenu();
    }

    ImGui::Separator();

    // Backend switch (Metal arrives in Milestone 3)
    ImGui::PushStyleColor(ImGuiCol_Text, ImGui::ColorConvertU32ToFloat4(colors::Glsl));
    ImGui::Button("GLSL");
    ImGui::PopStyleColor();
    ImGui::BeginDisabled();
    ImGui::Button("Metal");
    ImGui::EndDisabled();
    if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled))
        ImGui::SetTooltip("Metal (MSL) backend: Milestone 3");

    ImGui::Separator();

    if (ImGui::Button("Rewind")) {
        time_ = 0.0;
        frame_ = 0;
    }
    if (ImGui::Button(playing_ ? "Pause" : "Play ")) playing_ = !playing_;

    char buf[64];
    const int mins = static_cast<int>(time_) / 60;
    std::snprintf(buf, sizeof(buf), "%02d:%05.2f", mins, time_ - mins * 60.0);
    ImGui::PushFont(fonts_.mono, 0.0f);
    ImGui::TextUnformatted(buf);
    std::snprintf(buf, sizeof(buf), "%.0f fps", ImGui::GetIO().Framerate);
    ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(colors::Accent), "%s", buf);
    ImGui::PopFont();

    ImGui::Separator();
    ImGui::SetNextItemWidth(130.0f);
    if (ImGui::BeginCombo("##output", kOutputs[outputMode_].label)) {
        for (int i = 0; i < IM_ARRAYSIZE(kOutputs); ++i)
            if (ImGui::Selectable(kOutputs[i].label, i == outputMode_)) outputMode_ = i;
        ImGui::EndCombo();
    }

    accentButtonColors();
    if (ImGui::Button("Compile")) compile("button");
    ImGui::PopStyleColor(4);
    if (ImGui::Button("Overlay")) setOverlay(true);

    ImGui::EndMainMenuBar();
}

void App::drawDockspace() {
    const ImGuiID dockId = ImHashStr("ShaderStudioDockspace");
    const ImGuiViewport* vp = ImGui::GetMainViewport();

    if (!layoutBuilt_ || resetLayout_) {
        layoutBuilt_ = true;
        ImGuiDockNode* node = ImGui::DockBuilderGetNode(dockId);
        if (resetLayout_ || node == nullptr || node->IsLeafNode()) {
            resetLayout_ = false;
            ImGui::DockBuilderRemoveNode(dockId);
            ImGui::DockBuilderAddNode(dockId, ImGuiDockNodeFlags_DockSpace);
            ImGui::DockBuilderSetNodeSize(dockId, vp->WorkSize);

            ImGuiID left = 0, right = 0;
            ImGui::DockBuilderSplitNode(dockId, ImGuiDir_Left, 0.56f, &left, &right);
            ImGuiID leftBottom = 0;
            ImGui::DockBuilderSplitNode(left, ImGuiDir_Down, 0.22f, &leftBottom, &left);
            ImGuiID rightTop = 0, rightBottom = 0;
            ImGui::DockBuilderSplitNode(right, ImGuiDir_Up, 0.45f, &rightTop, &rightBottom);
            ImGuiID texNode = 0, uniNode = 0;
            ImGui::DockBuilderSplitNode(rightBottom, ImGuiDir_Up, 0.55f, &texNode, &uniNode);

            ImGui::DockBuilderDockWindow(kWinEditor, left);
            ImGui::DockBuilderDockWindow(kWinConsole, leftBottom);
            ImGui::DockBuilderDockWindow(kWinPreview, rightTop);
            ImGui::DockBuilderDockWindow(kWinTextures, texNode);
            ImGui::DockBuilderDockWindow(kWinUniforms, uniNode);
            ImGui::DockBuilderFinish(dockId);
        }
    }
    ImGui::DockSpaceOverViewport(dockId, vp);
}

void App::drawEditor() {
    std::string title = shaderPath_.empty() ? "untitled.frag" : shaderPath_.filename().string();
    if (isDirty()) title += " *";
    title += "###";
    title += kWinEditor;

    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    if (ImGui::Begin(title.c_str())) {
        ImGui::PushFont(fonts_.mono, 0.0f);
        editor_.Render("##code");
        ImGui::PopFont();
    }
    ImGui::End();
    ImGui::PopStyleVar();
}

void App::drawPreview() {
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(6, 6));
    if (ImGui::Begin(kWinPreview)) {
        const ImVec2 avail = ImGui::GetContentRegionAvail();
        const ImVec2 scale = ImGui::GetIO().DisplayFramebufferScale;
        if (outputMode_ == 0) {
            desiredW_ = std::max(1, static_cast<int>(avail.x * scale.x));
            desiredH_ = std::max(1, static_cast<int>(avail.y * scale.y));
        }

        // Fit the render target into the panel, preserving aspect.
        const float rtW = static_cast<float>(target_->width());
        const float rtH = static_cast<float>(target_->height());
        const float s = std::min(avail.x / rtW, avail.y / rtH);
        const ImVec2 size(std::max(1.0f, rtW * s), std::max(1.0f, rtH * s));
        const ImVec2 cursor = ImGui::GetCursorScreenPos();
        const ImVec2 origin(cursor.x + (avail.x - size.x) * 0.5f, cursor.y + (avail.y - size.y) * 0.5f);
        ImGui::SetCursorScreenPos(origin);

        if (program_) {
            ImGui::Image(texId(target_->color()), size, ImVec2(0, 1), ImVec2(1, 0));
        } else {
            ImGui::Dummy(size);
        }

        // Mouse in render-target pixels, origin bottom-left (Shadertoy convention for xy / zw).
        if (ImGui::IsItemHovered()) {
            const ImVec2 m = ImGui::GetIO().MousePos;
            const float mx = (m.x - origin.x) / size.x * rtW;
            const float my = (1.0f - (m.y - origin.y) / size.y) * rtH;
            if (ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
                mouse_[0] = mx;
                mouse_[1] = my;
            }
            if (ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
                mouse_[2] = mx;
                mouse_[3] = my;
            }
        }

        // Stats chip
        char buf[96];
        std::snprintf(buf, sizeof(buf), "%d×%d · %.1f ms frame", target_->width(), target_->height(),
                      1000.0f / std::max(1.0f, ImGui::GetIO().Framerate));
        ImDrawList* dl = ImGui::GetWindowDrawList();
        const ImVec2 ts = ImGui::CalcTextSize(buf);
        const ImVec2 p0(origin.x + 8, origin.y + 8);
        dl->AddRectFilled(p0, ImVec2(p0.x + ts.x + 12, p0.y + ts.y + 6), IM_COL32(10, 11, 14, 200), 5.0f);
        dl->AddText(ImVec2(p0.x + 6, p0.y + 3), IM_COL32(242, 244, 247, 255), buf);
    }
    ImGui::End();
    ImGui::PopStyleVar();
}

void App::drawConsole() {
    if (ImGui::Begin(kWinConsole)) {
        int errors = 0;
        for (const auto& d : diagnostics_)
            if (d.isError) ++errors;
        if (ImGui::SmallButton("Clear")) log_.clear();
        ImGui::SameLine();
        ImGui::TextDisabled("Problems %d", errors);
        ImGui::SameLine();
        ImGui::TextDisabled("· last compile %.1f ms", lastCompileMs_);
        ImGui::SameLine();
        ImGui::Checkbox("Auto-compile", &autoCompile_);
        ImGui::Separator();

        ImGui::BeginChild("##log", ImVec2(0, 0), ImGuiChildFlags_None, ImGuiWindowFlags_HorizontalScrollbar);
        ImGui::PushFont(fonts_.mono, 0.0f);
        for (const auto& e : log_) {
            ImU32 c = IM_COL32(183, 188, 198, 255);
            const char* tag = "INFO";
            switch (e.level) {
                case Level::Info: c = colors::Glsl; tag = "INFO"; break;
                case Level::Ok: c = colors::Accent; tag = "OK  "; break;
                case Level::Warn: c = IM_COL32(255, 200, 90, 255); tag = "WARN"; break;
                case Level::Error: c = colors::Error; tag = "ERR "; break;
            }
            ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(colors::Muted), "%s", e.time.c_str());
            ImGui::SameLine();
            ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(c), "%s", tag);
            ImGui::SameLine();
            ImGui::TextUnformatted(e.text.c_str());
        }
        if (scrollLog_) {
            ImGui::SetScrollHereY(1.0f);
            scrollLog_ = false;
        }
        ImGui::PopFont();
        ImGui::EndChild();
    }
    ImGui::End();
}

void App::drawTextures() {
    if (ImGui::Begin(kWinTextures)) {
        auto& slots = textures_->slots();
        ImGui::TextDisabled("%zu bound · up to %d units", slots.size(), device_->maxTextureUnits());

        int removeIndex = -1, moveFrom = -1, moveTo = -1;
        for (size_t i = 0; i < slots.size(); ++i) {
            auto& s = slots[i];
            ImGui::PushID(static_cast<int>(i));
            ImGui::Separator();

            const float thumb = 56.0f;
            if (s.texture) {
                const bool flipped = s.kind != textures::SourceKind::Image || s.flipY;
                ImGui::Image(texId(*s.texture), ImVec2(thumb, thumb), flipped ? ImVec2(0, 1) : ImVec2(0, 0),
                             flipped ? ImVec2(1, 0) : ImVec2(1, 1));
            }
            ImGui::SameLine();
            ImGui::BeginGroup();
            ImGui::TextUnformatted(s.name.c_str());
            ImGui::SameLine();
            ImGui::PushFont(fonts_.mono, 0.0f);
            ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(colors::Glsl), "u_tex%zu", i);
            ImGui::PopFont();
            if (s.texture) ImGui::TextDisabled("%d×%d · RGBA8", s.texture->width(), s.texture->height());

            bool samplerChanged = false;
            int filter = static_cast<int>(s.sampler.filter);
            int wu = static_cast<int>(s.sampler.wrapU);
            int wv = static_cast<int>(s.sampler.wrapV);
            ImGui::SetNextItemWidth(92.0f);
            samplerChanged |= ImGui::Combo("##filter", &filter, kFilterNames, 3);
            ImGui::SameLine();
            ImGui::SetNextItemWidth(80.0f);
            samplerChanged |= ImGui::Combo("##wu", &wu, kWrapNames, 3);
            ImGui::SameLine();
            ImGui::SetNextItemWidth(80.0f);
            samplerChanged |= ImGui::Combo("##wv", &wv, kWrapNames, 3);
            if (samplerChanged) {
                s.sampler.filter = static_cast<rhi::Filter>(filter);
                s.sampler.wrapU = static_cast<rhi::Wrap>(wu);
                s.sampler.wrapV = static_cast<rhi::Wrap>(wv);
                textures_->applySampler(i);
            }

            if (s.kind == textures::SourceKind::Image) {
                if (ImGui::Checkbox("Flip Y", &s.flipY)) textures_->reload(i);
                ImGui::SameLine();
                if (ImGui::SmallButton("Reload")) {
                    if (auto err = textures_->reload(i); !err.empty()) log(Level::Error, err);
                }
                ImGui::SameLine();
            }
            if (ImGui::SmallButton("Up") && i > 0) { moveFrom = static_cast<int>(i); moveTo = static_cast<int>(i) - 1; }
            ImGui::SameLine();
            if (ImGui::SmallButton("Down") && i + 1 < slots.size()) { moveFrom = static_cast<int>(i); moveTo = static_cast<int>(i) + 1; }
            ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Text, ImGui::ColorConvertU32ToFloat4(colors::Error));
            if (ImGui::SmallButton("Remove")) removeIndex = static_cast<int>(i);
            ImGui::PopStyleColor();
            ImGui::EndGroup();
            ImGui::PopID();
        }
        if (removeIndex >= 0) textures_->remove(static_cast<size_t>(removeIndex));
        if (moveFrom >= 0) textures_->move(static_cast<size_t>(moveFrom), static_cast<size_t>(moveTo));

        ImGui::Separator();
        const bool full = static_cast<int>(slots.size()) >= device_->maxTextureUnits();
        ImGui::BeginDisabled(full);
        accentButtonColors();
        if (ImGui::Button("+ Add image…")) pendingPopup_ = PathPopup::AddImage;
        ImGui::PopStyleColor(4);
        ImGui::SameLine();
        if (ImGui::Button("+ Noise")) textures_->addNoise();
        ImGui::SameLine();
        if (ImGui::Button("+ Checker")) textures_->addChecker();
        ImGui::EndDisabled();
        ImGui::TextDisabled("Or drop PNG / JPG / TGA / HDR files anywhere on the window.");
    }
    ImGui::End();
}

void App::drawUniforms() {
    if (ImGui::Begin(kWinUniforms)) {
        if (!program_) {
            ImGui::TextDisabled("No compiled shader yet.");
            ImGui::End();
            return;
        }
        ImGui::PushFont(fonts_.mono, 0.0f);
        ImGui::TextDisabled("time %.2f · frame %d · mouse %.0f,%.0f", time_, frame_, mouse_[0], mouse_[1]);
        ImGui::PopFont();
        ImGui::Separator();

        bool any = false;
        for (const auto& u : program_->uniforms()) {
            if (u.type == rhi::UniformType::Sampler2D || builtinFor(u.name) != Builtin::None) continue;
            any = true;
            auto& v = uniformValues_[u.name];
            const auto it = annotations_.find(u.name);
            const shader::Annotation a = it != annotations_.end() ? it->second : shader::Annotation{};
            using K = shader::Annotation::Kind;
            const char* label = u.name.c_str();

            ImGui::PushID(label);
            ImGui::SetNextItemWidth(-140.0f);
            switch (u.type) {
                case rhi::UniformType::Float:
                    if (a.kind == K::Slider) ImGui::SliderFloat(label, &v.f[0], a.min, a.max);
                    else if (a.kind == K::Toggle) {
                        bool b = v.f[0] > 0.5f;
                        if (ImGui::Checkbox(label, &b)) v.f[0] = b ? 1.0f : 0.0f;
                    } else ImGui::DragFloat(label, &v.f[0], a.speed);
                    break;
                case rhi::UniformType::Vec2:
                    if (a.kind == K::Slider) ImGui::SliderFloat2(label, v.f.data(), a.min, a.max);
                    else ImGui::DragFloat2(label, v.f.data(), a.speed);
                    break;
                case rhi::UniformType::Vec3:
                    if (a.kind == K::Color) ImGui::ColorEdit3(label, v.f.data());
                    else if (a.kind == K::Slider) ImGui::SliderFloat3(label, v.f.data(), a.min, a.max);
                    else ImGui::DragFloat3(label, v.f.data(), a.speed);
                    break;
                case rhi::UniformType::Vec4:
                    if (a.kind == K::Color) ImGui::ColorEdit4(label, v.f.data());
                    else if (a.kind == K::Slider) ImGui::SliderFloat4(label, v.f.data(), a.min, a.max);
                    else ImGui::DragFloat4(label, v.f.data(), a.speed);
                    break;
                case rhi::UniformType::Int:
                    if (a.kind == K::Slider) ImGui::SliderInt(label, &v.i, static_cast<int>(a.min), static_cast<int>(a.max));
                    else ImGui::DragInt(label, &v.i);
                    break;
                case rhi::UniformType::Bool: {
                    bool b = v.i != 0;
                    if (ImGui::Checkbox(label, &b)) v.i = b ? 1 : 0;
                    break;
                }
                default:
                    ImGui::TextDisabled("%s (unsupported type)", label);
                    break;
            }
            ImGui::PopID();
        }
        if (!any) ImGui::TextDisabled("Declare a uniform to get a control, e.g.\nuniform float u_amount; // @slider 0..1 0.5");
        ImGui::Spacing();
        if (ImGui::SmallButton("Reset to defaults")) {
            uniformValues_.clear();
            syncUniformDefaults();
        }
    }
    ImGui::End();
}

void App::drawOverlay() {
    const ImGuiViewport* vp = ImGui::GetMainViewport();
    const ImVec2 scale = ImGui::GetIO().DisplayFramebufferScale;
    desiredW_ = std::max(1, static_cast<int>(vp->Size.x * scale.x));
    desiredH_ = std::max(1, static_cast<int>(vp->Size.y * scale.y));

    ImDrawList* bg = ImGui::GetBackgroundDrawList();
    if (program_)
        bg->AddImage(texId(target_->color()), vp->Pos, ImVec2(vp->Pos.x + vp->Size.x, vp->Pos.y + vp->Size.y),
                     ImVec2(0, 1), ImVec2(1, 0));
    bg->AddRectFilled(vp->Pos, ImVec2(vp->Pos.x + vp->Size.x, vp->Pos.y + vp->Size.y),
                      IM_COL32(0, 0, 0, static_cast<int>(overlayDim_ * 255.0f)));

    // u_mouse follows the cursor in overlay mode.
    const ImVec2 m = ImGui::GetIO().MousePos;
    mouse_[0] = (m.x - vp->Pos.x) * scale.x;
    mouse_[1] = static_cast<float>(desiredH_) - (m.y - vp->Pos.y) * scale.y;

    ImGui::SetNextWindowPos(vp->Pos);
    ImGui::SetNextWindowSize(vp->Size);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, IM_COL32(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_ChildBg, IM_COL32(0, 0, 0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::Begin("##overlay", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoDocking |
                     ImGuiWindowFlags_NoBringToFrontOnFocus);

    if (ImGui::Button("Exit overlay (Esc)")) setOverlay(false);
    ImGui::SameLine();
    char buf[64];
    std::snprintf(buf, sizeof(buf), "%.2f s · %.0f fps", time_, ImGui::GetIO().Framerate);
    ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(colors::Accent), "%s", buf);
    ImGui::SameLine();
    ImGui::SetNextItemWidth(160.0f);
    ImGui::SliderFloat("Dim", &overlayDim_, 0.0f, 0.9f, "%.2f");
    ImGui::SameLine();
    if (ImGui::Button(playing_ ? "Pause" : "Play ")) playing_ = !playing_;
    ImGui::SameLine();
    accentButtonColors();
    if (ImGui::Button("Compile (F5)")) compile("button");
    ImGui::PopStyleColor(4);

    ImGui::PushFont(fonts_.mono, 18.0f);
    editor_.Render("##overlay_code");
    ImGui::PopFont();

    ImGui::End();
    ImGui::PopStyleVar();
    ImGui::PopStyleColor(2);
}

void App::drawPopups() {
    static const char* const kTitles[] = {"", "Open shader", "Save shader as", "Add image texture"};
    if (pendingPopup_ != PathPopup::None) {
        const char* title = kTitles[static_cast<int>(pendingPopup_)];
        if (pendingPopup_ == PathPopup::SaveAs && !shaderPath_.empty())
            std::snprintf(pathBuf_, sizeof(pathBuf_), "%s", shaderPath_.string().c_str());
        ImGui::OpenPopup(title);
        activePopup_ = pendingPopup_;
        pendingPopup_ = PathPopup::None;
    }
    if (activePopup_ == PathPopup::None) return;

    const char* title = kTitles[static_cast<int>(activePopup_)];
    ImGui::SetNextWindowSize(ImVec2(560, 0), ImGuiCond_Appearing);
    if (ImGui::BeginPopupModal(title, nullptr, ImGuiWindowFlags_NoSavedSettings)) {
        ImGui::TextDisabled("Absolute path (tip: you can also drag files onto the window)");
        if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere();
        ImGui::SetNextItemWidth(-1);
        const bool enter = ImGui::InputText("##path", pathBuf_, sizeof(pathBuf_), ImGuiInputTextFlags_EnterReturnsTrue);
        const bool ok = ImGui::Button("OK", ImVec2(100, 0)) || enter;
        ImGui::SameLine();
        const bool cancel = ImGui::Button("Cancel", ImVec2(100, 0));

        if (ok && pathBuf_[0] != '\0') {
            const fs::path p = pathBuf_;
            bool done = false;
            switch (activePopup_) {
                case PathPopup::Open: done = openShader(p); break;
                case PathPopup::SaveAs: done = saveShader(p); break;
                case PathPopup::AddImage:
                    if (auto err = textures_->addImage(p); !err.empty()) log(Level::Error, err);
                    else {
                        log(Level::Ok, "Added texture " + p.filename().string());
                        done = true;
                    }
                    break;
                default: break;
            }
            if (done) {
                activePopup_ = PathPopup::None;
                ImGui::CloseCurrentPopup();
            }
        }
        if (cancel) {
            activePopup_ = PathPopup::None;
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    } else {
        activePopup_ = PathPopup::None;
    }
}

}  // namespace app
