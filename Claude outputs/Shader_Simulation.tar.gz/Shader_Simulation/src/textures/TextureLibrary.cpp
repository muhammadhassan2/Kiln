#include "textures/TextureLibrary.h"

#include <stb_image.h>

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <random>

namespace fs = std::filesystem;

namespace textures {

TextureLibrary::TextureLibrary(rhi::Device& device) : device_(device) {
    const std::uint8_t black[4] = {0, 0, 0, 255};
    fallback_ = device_.createTexture(1, 1, rhi::Format::RGBA8, black);
}

bool TextureLibrary::isImageFile(const fs::path& p) {
    std::string ext = p.extension().string();
    std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return std::tolower(c); });
    return ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".bmp" || ext == ".tga" ||
           ext == ".gif" || ext == ".psd" || ext == ".hdr";
}

std::string TextureLibrary::loadInto(TextureSlot& slot) {
    stbi_set_flip_vertically_on_load(slot.flipY ? 1 : 0);
    int w = 0, h = 0, n = 0;
    stbi_uc* pixels = stbi_load(slot.path.string().c_str(), &w, &h, &n, 4);
    if (!pixels) return std::string("Could not load ") + slot.path.string() + ": " + stbi_failure_reason();

    if (slot.texture) slot.texture->upload(pixels, w, h);
    else slot.texture = device_.createTexture(w, h, rhi::Format::RGBA8, pixels);
    stbi_image_free(pixels);

    slot.texture->setSampler(slot.sampler);
    std::error_code ec;
    slot.mtime = fs::last_write_time(slot.path, ec);
    return {};
}

std::string TextureLibrary::addImage(const fs::path& path) {
    TextureSlot slot;
    slot.kind = SourceKind::Image;
    slot.path = path;
    slot.name = path.filename().string();
    if (auto err = loadInto(slot); !err.empty()) return err;
    slots_.push_back(std::move(slot));
    return {};
}

void TextureLibrary::addNoise(int size) {
    std::vector<std::uint8_t> px(static_cast<size_t>(size * size * 4));
    std::mt19937 rng(1337u + static_cast<unsigned>(slots_.size()));
    std::uniform_int_distribution<int> dist(0, 255);
    for (auto& v : px) v = static_cast<std::uint8_t>(dist(rng));
    TextureSlot slot;
    slot.kind = SourceKind::Noise;
    slot.name = "noise_rgba " + std::to_string(size);
    slot.texture = device_.createTexture(size, size, rhi::Format::RGBA8, px.data());
    slot.texture->setSampler(slot.sampler);
    slots_.push_back(std::move(slot));
}

void TextureLibrary::addChecker(int size) {
    std::vector<std::uint8_t> px(static_cast<size_t>(size * size * 4));
    const int cell = std::max(1, size / 8);
    for (int y = 0; y < size; ++y)
        for (int x = 0; x < size; ++x) {
            const bool on = ((x / cell) + (y / cell)) % 2 == 0;
            auto* p = &px[static_cast<size_t>((y * size + x) * 4)];
            p[0] = p[1] = p[2] = on ? 230 : 40;
            p[3] = 255;
        }
    TextureSlot slot;
    slot.kind = SourceKind::Checker;
    slot.name = "checker " + std::to_string(size);
    slot.sampler.filter = rhi::Filter::Nearest;
    slot.texture = device_.createTexture(size, size, rhi::Format::RGBA8, px.data());
    slot.texture->setSampler(slot.sampler);
    slots_.push_back(std::move(slot));
}

void TextureLibrary::remove(size_t index) {
    if (index < slots_.size()) slots_.erase(slots_.begin() + static_cast<std::ptrdiff_t>(index));
}

void TextureLibrary::move(size_t from, size_t to) {
    if (from >= slots_.size() || to >= slots_.size() || from == to) return;
    std::swap(slots_[from], slots_[to]);
}

std::string TextureLibrary::reload(size_t index) {
    if (index >= slots_.size() || slots_[index].kind != SourceKind::Image) return {};
    return loadInto(slots_[index]);
}

void TextureLibrary::applySampler(size_t index) {
    if (index < slots_.size() && slots_[index].texture) slots_[index].texture->setSampler(slots_[index].sampler);
}

std::vector<std::string> TextureLibrary::pollHotReload() {
    std::vector<std::string> changed;
    for (auto& s : slots_) {
        if (s.kind != SourceKind::Image) continue;
        std::error_code ec;
        const auto t = fs::last_write_time(s.path, ec);
        if (!ec && t != s.mtime && loadInto(s).empty()) changed.push_back(s.name);
    }
    return changed;
}

}  // namespace textures
