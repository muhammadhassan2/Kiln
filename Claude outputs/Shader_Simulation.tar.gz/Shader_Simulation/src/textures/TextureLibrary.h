#pragma once

#include "rhi/RHI.h"

#include <filesystem>
#include <memory>
#include <string>
#include <vector>

namespace textures {

enum class SourceKind { Image, Noise, Checker };

struct TextureSlot {
    std::string name;
    SourceKind kind = SourceKind::Image;
    std::filesystem::path path;  // Image only
    std::filesystem::file_time_type mtime{};
    bool flipY = true;
    rhi::SamplerDesc sampler;
    std::unique_ptr<rhi::Texture> texture;
};

// Owns the ordered list of textures. Slot i is bound to u_tex<i> / iChannel<i>
// (GLSL) or [[texture(i)]] (Metal). There is no fixed count; the device limit applies.
class TextureLibrary {
public:
    explicit TextureLibrary(rhi::Device& device);

    // Returns an error message on failure, empty on success.
    std::string addImage(const std::filesystem::path& path);
    void addNoise(int size = 256);
    void addChecker(int size = 256);

    void remove(size_t index);
    void move(size_t from, size_t to);
    std::string reload(size_t index);
    void applySampler(size_t index);

    // Poll file timestamps and reload changed images. Returns names that reloaded.
    std::vector<std::string> pollHotReload();

    std::vector<TextureSlot>& slots() { return slots_; }
    const rhi::Texture& fallback() const { return *fallback_; }

    static bool isImageFile(const std::filesystem::path& p);

private:
    std::string loadInto(TextureSlot& slot);

    rhi::Device& device_;
    std::vector<TextureSlot> slots_;
    std::unique_ptr<rhi::Texture> fallback_;  // 1×1 black for unbound samplers
};

}  // namespace textures
