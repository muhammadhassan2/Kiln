#pragma once
// Thin render-hardware interface. The app talks only to these types, so the
// Metal backend (Milestone 3) is a new folder next to rhi/gl, not a refactor.

#include <cstdint>
#include <memory>
#include <span>
#include <string>
#include <vector>

namespace rhi {

enum class Filter { Nearest, Linear, Trilinear };
enum class Wrap { Repeat, Clamp, Mirror };
enum class Format { RGBA8, RGBA16F, RGBA32F };

struct SamplerDesc {
    Filter filter = Filter::Trilinear;
    Wrap wrapU = Wrap::Repeat;
    Wrap wrapV = Wrap::Repeat;
};

class Texture {
public:
    virtual ~Texture() = default;
    virtual int width() const = 0;
    virtual int height() const = 0;
    virtual void setSampler(const SamplerDesc& desc) = 0;
    // RGBA8 pixels, rows bottom-to-top. Reallocates when the size changes.
    virtual void upload(const void* rgba8, int w, int h) = 0;
    // GL texture name / MTLTexture* — used for ImGui display.
    virtual std::uint64_t nativeHandle() const = 0;
};

class RenderTarget {
public:
    virtual ~RenderTarget() = default;
    virtual void resize(int w, int h) = 0;
    virtual int width() const = 0;
    virtual int height() const = 0;
    virtual Texture& color() = 0;
};

enum class UniformType { Float, Vec2, Vec3, Vec4, Int, Bool, Sampler2D, Other };

struct UniformInfo {
    std::string name;  // without "[0]"
    UniformType type = UniformType::Other;
    int location = -1;
    int arraySize = 1;
};

struct Diagnostic {
    int line = 0;  // 1-based line in the user's source, 0 = unknown
    std::string message;
    bool isError = true;
};

class Program {
public:
    virtual ~Program() = default;
    virtual const std::vector<UniformInfo>& uniforms() const = 0;
};

struct CompileResult {
    std::unique_ptr<Program> program;  // null on failure
    std::string log;
    std::vector<Diagnostic> diagnostics;
    double milliseconds = 0.0;
    bool ok() const { return program != nullptr; }
};

struct UniformValue {
    int location = -1;
    UniformType type = UniformType::Float;
    float f[4]{};
    int i = 0;
};

struct TextureBinding {
    int location = -1;
    int unit = 0;
    const Texture* texture = nullptr;
};

class Device {
public:
    virtual ~Device() = default;
    virtual std::string name() const = 0;
    virtual std::string languageVersion() const = 0;
    virtual int maxTextureUnits() const = 0;

    virtual std::unique_ptr<Texture> createTexture(int w, int h, Format format, const void* rgba8 = nullptr) = 0;
    virtual std::unique_ptr<RenderTarget> createRenderTarget(int w, int h, Format format) = 0;

    // Compiles a full-screen fragment shader written by the user.
    virtual CompileResult compileFragment(const std::string& source) = 0;

    virtual void draw(const Program& program, RenderTarget& target,
                      std::span<const UniformValue> uniforms,
                      std::span<const TextureBinding> textures) = 0;
};

std::unique_ptr<Device> createGLDevice();

}  // namespace rhi
