# Shader Studio (Shader_Simulation)

A live GLSL shader editor in the style of KodeLife. This is Milestone 1, running on OpenGL 4.1 core. The rendering code sits behind a small interface in `src/rhi`, so the Metal backend can be added later as a new folder.

## Build

Open the folder in CLion and run it. To build from a terminal instead:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
./build/Shader_Simulation [shader.frag] [image.png ...]
```

CMake downloads the dependencies the first time you configure, each pinned to a fixed version:

- GLFW 3.4
- Dear ImGui v1.92.9b (docking branch)
- goossens/ImGuiColorTextEdit (code editor)
- stb_image
- GLEW (Windows and Linux only; macOS uses the system OpenGL headers)

## Features

| | |
|---|---|
| Editor | GLSL syntax highlighting. Recompiles automatically 300 ms after you stop typing; F5 forces a compile. Compile errors are marked on their lines and the last working shader keeps running. |
| Preview | Fits the panel, or renders at a fixed output size. Supports retina displays. The mouse sets `u_mouse` in pixels. |
| Textures | No fixed limit (only the GPU's). Slot *i* is `u_texi`, or `iChannel i` for Shadertoy code. You can set filtering and edge wrapping, flip Y, reorder, reload and remove textures. Image files reload when they change on disk. Built-in noise and checker textures are included. |
| Uniforms | Found automatically when the shader compiles. Comments next to a uniform turn into controls: `// @slider 0..2 0.85`, `// @color #FFB27A`, `// @toggle`, `// @drag 0.01`. |
| Built-ins | `u_time`, `u_timeDelta`, `u_frame`, `u_resolution`, `u_mouse`, plus the Shadertoy names `iTime`, `iResolution`, `iMouse`, `iFrame`. |
| Files | Drag shaders or images onto the window. Ctrl/Cmd+O opens, Ctrl/Cmd+S saves. If the shader file changes on disk (for example, edited in another editor), it reloads automatically. |
| Overlay mode | F2 shows the code over the full-screen output. Esc exits. |

## Layout

```
main.cpp                    window, GL context, ImGui, main loop
src/rhi/RHI.h               Device / Texture / RenderTarget / Program interfaces
src/rhi/gl/                 OpenGL backend
src/shader/                 compile-log parsing, @annotation parsing
src/textures/               TextureLibrary (slots, image loading, hot reload)
src/app/                    App (UI panels, playback, files), theme, default shader
```

## Next milestones

2. Save and load projects (`project.json` with the texture list and uniform values), plus a native file dialog.
3. Metal backend (`src/rhi/metal`, using metal-cpp). GLSL is converted to Metal with glslang and SPIRV-Cross.
4. Multiple render passes and feedback buffers.
5. Video, camera and audio-FFT textures.
6. Export to image sequences or video.
